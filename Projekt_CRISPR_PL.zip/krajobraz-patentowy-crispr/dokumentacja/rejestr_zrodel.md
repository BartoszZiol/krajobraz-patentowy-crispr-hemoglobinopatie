# Rejestr źródeł

Lista źródeł, do których odnoszą się raport i arkusz. Numery spraw dotyczą konkretnych zgłoszeń, a nie automatycznie całych rodzin patentowych.

| Oznaczenie | Dokument | Źródło | Zakres dowodowy |
| --- | --- | --- | --- |
| P1 | EP3981876A1 | [European Patent Register](https://register.epo.org/application?number=EP21170121&lng=en) | Zgłoszenie Editas, opinia EPO i zmiany zastrzeżeń. |
| P2 | WO2015071474A2 | [Publikacja](https://patents.google.com/patent/WO2015071474A2/en) | Dokument D1 do analizy Editas. |
| P3 | EP3887521A1 | [European Patent Register](https://register.epo.org/application?number=EP19824433&lng=en) | Wycofanie zgłoszenia Editas. |
| P4 | EP3749767A1 | [European Patent Register](https://register.epo.org/application?number=EP19713183&lng=en) | Wycofanie zgłoszenia Vertex. |
| P5 | EP4747377A1 | [European Patent Register](https://register.epo.org/application?number=EP24745917&lng=en) | Prime editing, region -115. |
| P6 | EP4747376A1 | [European Patent Register](https://register.epo.org/application?number=EP24740480&lng=en) | Prime editing, region -200. |
| P7 | WO2025147212A1 | [Publikacja](https://patents.google.com/patent/WO2025147212A1/en) | Nikazy Cas9 i HBG. |
| P8 | WO2025181336A1 | [Publikacja](https://patents.google.com/patent/WO2025181336A1/en) | Alternatywna technologia TALEN/HDR. |
| R1 | Definicja rodzin DOCDB | [EPO](https://www.epo.org/en/searching-for-patents/helpful-resources/first-time-here/patent-families/docdb) | Metoda ustalania rodzin patentowych. |
| R2-R6 | Art. 53, 54, 56, 84 i 123 EPC | [EPC](https://www.epo.org/en/legal/epc/) | Podstawy prawa patentowego. |
| R7 | Wytyczne badania EPO 2026 | [EPO](https://www.epo.org/en/legal/guidelines-epc/2026/index.html) | Praktyka oceny zastrzeżeń. |

Oryginalne eksporty XLS znajdują się w katalogu `materialy_zrodlowe/`. Ich treści nie tłumaczono, ponieważ stanowią dokumentację pierwotną.
