# Metodyka badania i kontrola jakości

## Cel i źródło

Badanie dotyczy sposobów ubiegania się o ochronę patentową dla edycji genomu istotnej w leczeniu beta-hemoglobinopatii, ze szczególnym naciskiem na BCL11A, HBG1/HBG2 i HBB. Podstawę stanowi sześć kolejnych eksportów XLS z Espacenet Worldwide pochodzących z jednego zestawu wyników wyszukiwania

## Jednostka analizy

Podstawową jednostką jest **rekord publikacji**. Nie należy utożsamiać go z rodziną patentową, zgłoszeniem, udzielonym patentem ani aktualnym właścicielem prawa. W eksporcie występuje 135 różnych głównych numerów publikacji.

Zidentyfikowano sześć grup rekordów ze wspólnymi numerami pierwszeństwa. To nie wystarcza do potwierdzenia członkostwa w jednej prostej rodzinie DOCDB. Pełnego zestawienia rodzin nie ustalono.

## Kryteria selekcji

- **A:** bezpośrednio związany technologicznie kandydat na podstawie dostępnych danych lub przeanalizowanych zastrzeżeń.
- **B:** temat terapeutyczny, ale sam mechanizm edycji lub jego obecność w zastrzeżeniach wymaga sprawdzenia.
- **C:** technologia pokrewna, wspomagająca lub porównawcza.
- **D:** dokument prawdopodobnie poza zakresem.

Klasy mają charakter wstępny. Zmiana klasy po analizie zastrzeżeń jest prawidłowym elementem metodyki, np. dla zgłoszenia Cellectis opartego na TALEN/HDR.

## Hierarchia dowodów

1. **Oficjalny European Patent Register:** status konkretnego zgłoszenia, czynności procesowe, dane zgłaszającego.
2. **Opublikowany tekst zastrzeżeń:** kategoria i cechy żądanej ochrony.
3. **Opinia z poszukiwania i korespondencja EPO:** uwagi odnoszone do konkretnej daty i wersji zastrzeżeń.
4. **Espacenet i inne dane bibliograficzne:** wyszukiwanie i wstępne grupowanie.
5. **Ocena analityczna:** wnioski wymagające dalszej weryfikacji oznaczone osobno.

## Najważniejsze ograniczenia

- Zapytanie nie obejmuje wszystkich patentów dotyczących hemoglobinopatii, ponieważ wymaga wystąpienia określonych słów.
- W wynikach mogą występować dokumenty, w których CRISPR pojawia się jedynie jako tło techniczne.
- Opublikowane zastrzeżenia WO i EP A1 nie przesądzają końcowego zakresu ochrony.
- Zmiany z 15 stycznia 2026 r. w EP4747376 i EP4747377 wymagają osobnego porównania z wersją WO.
- Kategorie X/Y w międzynarodowym sprawozdaniu z poszukiwań nie są same w sobie ostateczną decyzją o patentowalności.
- Dane o statusach rejestrowych pochodzą z wyciągów z listopada 2026 r. Nie oznacza to stałego monitorowania późniejszych zmian.

## Podstawy prawne

Artykuły 53(c), 54, 56, 84 i 123(2) EPC. Przy ocenie nowości konieczne jest odrębne ustalenie podstaw zastosowania art. 54(2) lub 54(3) EPC. W przypadku zastrzeżeń dotyczących sposobów leczenia należy odróżniać proces ex vivo i produkt terapeutyczny od zabiegu wykonywanego na ciele człowieka.
