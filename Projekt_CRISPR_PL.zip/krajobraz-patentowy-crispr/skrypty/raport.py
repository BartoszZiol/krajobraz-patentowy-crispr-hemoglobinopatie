#!/usr/bin/env python3
"""Tworzy polski raport o krajobrazie patentowym terapii hemoglobinopatii."""
from pathlib import Path
import csv
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, HRFlowable, KeepTogether
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parents[1]
PDF=ROOT/'Raport_krajobraz_patentowy_CRISPR_2013-2026_PL.pdf'
FIG=ROOT/'wykresy'
pdfmetrics.registerFont(TTFont('DejaVu','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVu-Bold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
pdfmetrics.registerFontFamily('DejaVu',normal='DejaVu',bold='DejaVu-Bold',italic='DejaVu',boldItalic='DejaVu-Bold')
N=colors.HexColor('#14283E');B=colors.HexColor('#20546B');T=colors.HexColor('#287F79');D=colors.HexColor('#293F52');M=colors.HexColor('#607381');L=colors.HexColor('#EDF3F6');W=colors.white
PW,PH=A4
S={
 'title':ParagraphStyle('Naglowek',fontName='DejaVu-Bold',fontSize=16.4,leading=21.7,textColor=N,spaceAfter=11),
 'sub':ParagraphStyle('Podtytul',fontName='DejaVu',fontSize=9.2,leading=13.6,textColor=M,spaceAfter=12),
 'h':ParagraphStyle('Srodek',fontName='DejaVu-Bold',fontSize=10.5,leading=14.7,textColor=B,spaceBefore=9,spaceAfter=6),
 'b':ParagraphStyle('Tekst',fontName='DejaVu',fontSize=8.65,leading=13.1,textColor=D,spaceAfter=8.1),
 's':ParagraphStyle('Maly',fontName='DejaVu',fontSize=7.15,leading=10.6,textColor=M,spaceAfter=6),
 'li':ParagraphStyle('Wypunktowany',fontName='DejaVu',fontSize=8.45,leading=12.8,textColor=D,spaceAfter=4.7,leftIndent=12,firstLineIndent=-9),
 'th':ParagraphStyle('TH',fontName='DejaVu-Bold',fontSize=7.2,leading=10.0,textColor=W),
 'td':ParagraphStyle('TD',fontName='DejaVu',fontSize=7.08,leading=10.25,textColor=D),
}
flow=[]

def p(t,sty='b'):return Paragraph(t,S[sty])
def para(t,sty='b'):flow.append(p(t.replace('\u2014','-'),sty))
def hd(t):para(t,'h')
def li(t):para('• '+t,'li')
def sec(t,detail):
 flow.append(PageBreak());para(t,'title');para(detail,'sub');flow.append(HRFlowable(width='100%',thickness=1.15,color=T,spaceAfter=12))
def tab(heads,rows,width=None):
 if width is None:width=[499/len(heads)]*len(heads)
 dat=[[p(str(x),'th') for x in heads]]+[[p(str(v).replace('\u2014','-'),'td') for v in row] for row in rows]
 t=Table(dat,colWidths=width,repeatRows=1,hAlign='LEFT',splitByRow=1)
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),B),('ROWBACKGROUNDS',(0,1),(-1,-1),[W,L]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#DBE5EB'))]))
 flow.append(t);flow.append(Spacer(1,8))
def img(name,caption,width=487):
 from PIL import Image as PImage
 q=PImage.open(FIG/name)
 w,h=q.size
 flow.append(Image(str(FIG/name),width=width,height=width*h/w))
 flow.append(Spacer(1,5));para(caption,'s')
def url(label,href):return f'<link href="{href}" color="#20546B">{label}</link>'

flow.append(Spacer(1,1))
sec('Streszczenie wykonawcze','Analiza danych z Espacenet | europejska perspektywa patentowa')
para('<b>Cel.</b> Analiza sposobów uzyskiwania ochrony patentowej dla technologii edycji genomu istotnych w leczeniu beta-hemoglobinopatii, w szczególności przy modyfikacji BCL11A, promotorów HBG1/HBG2 i genu HBB.')
para('<b>Zakres materiału.</b> Zebrano <b>135 odrębnych rekordów publikacji</b> z Espacenet, wytypowano <b>25 publikacji</b> do pogłębionej oceny oraz opracowano <b>6 przypadków związanych z CRISPR</b> i <b>jeden przypadek TALEN</b> jako technologię porównawczą.')
hd('Najważniejsze ustalenia')
li('Sposoby zwiększania hemoglobiny płodowej przez modyfikację enhancera BCL11A i promotorów HBG różnią się od bezpośredniej naprawy HBB. Także konstrukcja zastrzeżeń patentowych jest odmienna.')
li('Zgłoszenia obejmują różne kategorie: gRNA, zestawy zawierające nukleazy, sposoby edycji komórek ex vivo, zmodyfikowane komórki, kompozycje i sposoby terapii.')
li('W dwóch analizowanych postępowaniach EP doszło do wycofania zgłoszenia przez zgłaszającego; dla trzech innych spraw odnotowano wniosek o badanie, a nie udzielenie patentu.')
li('W obu zgłoszeniach INSERM/AP-HP dotyczących regionów -115 i -200 odnotowano zmiany dokumentacji 15 stycznia 2026 r. Opublikowane zastrzeżenia WO nie mogą być utożsamiane z ostatecznym zakresem EP.')
hd('Ograniczenie interpretacyjne')
para('Wszystkie wykresy opisują <b>publikacje z konkretnego zapytania</b>. Nie przedstawiają liczby odrębnych rodzin DOCDB, udzielonych patentów, udziałów rynkowych ani swobody prowadzenia działalności (FTO). Analiza ma charakter badawczy, nie jest opinią prawną.')

sec('1. Podstawy technologiczne','Trzy cele molekularne, różne drogi uzyskania efektu terapeutycznego')
para('Anemia sierpowatokrwinkowa oraz beta-talasemia wynikają z zaburzeń dotyczących hemoglobiny dorosłych. Podniesienie poziomu hemoglobiny płodowej (HbF, α₂γ₂) może łagodzić skutki zaburzeń beta-globiny. Alternatywnie możliwa jest korekcja wariantu w genie HBB.')
tab(['Cel','Podejście biologiczne','Przykładowe dokumenty'],[
 ('BCL11A - enhancer erytroidalny','Ograniczenie represji ekspresji gamma-globiny w komórkach linii erytroidalnej.','EP3981876A1; EP3749767A1'),
 ('HBG1/HBG2 - promotory','Zmiana miejsc wiązania represorów BCL11A lub LRF albo utworzenie miejsc dla aktywatorów KLF1, GATA1, TAL1.','EP3887521A1; WO2025147212A1; EP4747376A1; EP4747377A1'),
 ('HBB - region kodujący','Korekcja wariantu odpowiedzialnego za chorobę przez mechanizm naprawy DNA.','WO2025181336A1 - TALEN/HDR, wyłącznie porównawczo')
],[128,191,180])
hd('Zakres badania')
li('Główna kategoria: rozwiązania CRISPR/Cas9, nikazy Cas9, prime editing i powiązane sposoby edycji związane z hemoglobinopatiami lub HbF.')
li('Technologie pokrewne: TALEN, dostarczanie narzędzi, hodowle komórek i metody chemiczne - odnotowywane, ale niewliczane jako potwierdzone wynalazki CRISPR.')
li('Ramowy okres opisu to lata 2013-2026. W źródłowym eksporcie pozostawiono również trzy rekordy z pierwszeństwem z 2012 r.; nie usuwano ich bez śladu.')

sec('2. Metodyka i materiał','Wyszukiwanie, selekcja i hierarchia dowodów')
para('Wyszukiwanie przeprowadzono w bazie Espacenet Worldwide. Materiał obejmuje sześć kolejnych eksportów XLS, łącznie pozycje 1-135, pochodzących z wyników zapytania:')
para('<font color="#20546B">(ftxt = BCL11A AND ftxt = CRISPR) AND (((ta = hemoglobinopathy OR ta = hemoglobinopathies) OR ta = "sickle cell") OR ta = thalassemia)</font>')
tab(['Etap','Czynność','Rezultat'],[
 ('Pozyskanie','Połączenie sześciu stron wyników, zachowanie numerów publikacji, dat i danych bibliograficznych.','135 rekordów'),
 ('Selekcja','Ocena tytułu, zgłaszającego, klasyfikacji i sygnałów technologicznych; klasy A-D.','135 ocen wstępnych'),
 ('Lista do przeglądu','Wybór reprezentatywnych publikacji pod kątem celów i metod edycji.','25 kandydatów'),
 ('Przegląd zastrzeżeń','Analiza dokumentów WO i EP oraz wydruków European Patent Register.','7 studiów przypadku'),
 ('Powiązania rodzinne','Wykrycie wspólnych oznaczeń pierwszeństwa bez automatycznego uznania rodziny.','6 grup do weryfikacji')
],[89,309,101])
para('<b>Jednostka analizy:</b> rekord publikacji. Publikacja nie jest tożsama ze zgłoszeniem, rodziną patentową, wynalazkiem ani udzielonym patentem. Zbieżność dat i numerów pierwszeństwa stanowi przesłankę dalszego badania DOCDB, ale nie zastępuje jego wyniku. [R1]')
hd('Hierarchia źródeł')
li('Rejestr EPO: status i czynności procesowe konkretnych zgłoszeń EP.')
li('Opublikowane zastrzeżenia: cechy techniczne i żądane kategorie ochrony.')
li('Opinie z poszukiwania i korespondencja EPO: uwagi urzędu odnoszone do właściwej daty i wersji zastrzeżeń.')
li('Dane Espacenet: wyszukiwanie i wstępne mapowanie; wnioski interpretacyjne oznaczone jako wymagające weryfikacji.')

sec('3. Rozkład dat pierwszeństwa','Dane o publikacjach, a nie o niezależnych zgłoszeniach lub patentach')
img('lata_pierwszenstwa.png','Wykres 1. Najwcześniejszy rok pierwszeństwa w 135 rekordach publikacji. Duplikaty rodzin i różne drogi publikacji mogą wpływać na rozkład.',483)
para('Najwięcej rekordów w badanej próbie ma pierwszeństwo z <b>2021 r. (26)</b>, następnie z <b>2019 r. (18)</b>. Rozkład wynika także z konstrukcji zapytania i obecności publikacji z różnych urzędów; nie dowodzi szczytu światowej aktywności innowacyjnej w tych latach.')
para('Trzy rekordy z pierwszeństwem z 2012 r. uwzględniono w wykresie ze względu na integralność danych źródłowych. Analiza ograniczona ściśle do 2013-2026 wymaga ich odfiltrowania i ponownego przeliczenia mianownika.')

sec('4. Drogi publikacji','Zasięg bazy wyszukiwawczej nie jest miarą ochrony na terytorium')
img('urzedy_publikacji.png','Wykres 2. Pierwszy urząd lub droga publikacji wskazana w rekordzie. Oznaczenie WO nie stanowi patentu udzielonego.',475)
para('Zbiór obejmuje <b>80 publikacji US, 29 WO, 21 CN, 2 EP, 2 JP i 1 CA</b>. Przewaga publikacji US nie oznacza dominującego udziału amerykańskich podmiotów w wynalazkach ani struktury terytorialnej udzielonych praw.')
hd('Ważne rozróżnienie')
para('W jednej rodzinie mogą istnieć równoległe zgłoszenia i publikacje w kilku jurysdykcjach. Przy analizie zasięgu ochrony konieczne jest sprawdzenie statusów poszczególnych zgłoszeń i patentów krajowych lub regionalnych.')

sec('5. Selekcja i jakość trafień','Użyteczność zapytania i problem szerokich opisów patentowych')
img('selekcja_wstepna.png','Wykres 3. Kwalifikacja na podstawie tytułu i danych bibliograficznych; nie stanowi pełnej oceny zastrzeżeń.',476)
para('Do kategorii A zaliczono 35 publikacji, do B - 36, do C - 37, a do D - 27. Wyniki stanowią <b>wstępne klasy trafności</b>. Nie ma podstaw do nazywania 35 pozycji odrębnymi, potwierdzonymi rodzinami CRISPR.')
hd('Przykład korekty kwalifikacji')
para('Dokument <b>WO2025181336A1 (Cellectis)</b> występował w wynikach wyszukiwania, ale przeanalizowane zastrzeżenia dotyczą TALEN oraz naprawy HBB z użyciem matrycy HDR. Został zachowany jako porównanie technologiczne i wyłączony z rdzenia CRISPR.')
para('Podobny problem dotyczy dokumentów związanych z hodowlą komórek, narzędziami dostarczania lub aktywacją HbF metodami chemicznymi. Obecność frazy CRISPR w opisie nie przesądza, że dotyczy jej niezależne zastrzeżenie.')

sec('6. Zgłaszający w badanej próbie','Widoczność w wynikach wyszukiwania, nie miara siły portfela')
img('zglaszajacy.png','Wykres 4. Pierwszy podmiot wymieniony jako zgłaszający w rekordach bibliograficznych; nie uwzględnia podziału współzgłaszających.',481)
para('Wśród ujednoliconych pierwszych zgłaszających najczęściej pojawiają się <b>Editas Medicine (11 rekordów)</b>, <b>INSERM (9)</b>, <b>Novartis (8)</b> i <b>Vertex Pharmaceuticals (8)</b>. Wyniki wymagają ostrożności z powodu niepełnej normalizacji nazw i możliwych duplikatów publikacji rodzinnych.')
li('Pierwszy zgłaszający nie musi być jedynym ani aktualnym właścicielem praw.')
li('Wiele publikacji może dotyczyć tej samej rodziny lub kolejnych etapów postępowania.')
li('Zapytanie zawierające BCL11A może nie wykrywać części rodzin skupionych wyłącznie na HBB lub innych celach.')

sec('7. Konstrukcja ochrony patentowej','Przedmiot żądanej ochrony i zależności między kategoriami zastrzeżeń')
tab(['Kategoria zastrzeżenia','Znaczenie','Przykład'],[
 ('Produkt: gRNA / nukleaza / zestaw','Ochrona określonego składnika lub zestawu, zależna od wszystkich cech zastrzeżenia.','Editas EP3981876A1; WO2025147212A1'),
 ('Sposób edycji komórek ex vivo','Czynności wykonywane poza organizmem, często z określonym celem molekularnym.','Vertex EP3749767A1; prime editing WO'),
 ('Zmodyfikowane komórki','Populacje lub komórki uzyskane przez edycję, czasem ograniczone określonymi zmianami sekwencji.','EP4747376/77; Cellectis'),
 ('Kompozycja farmaceutyczna','Skład zawierający składniki narzędzia lub zmodyfikowane komórki.','WO2025147212A1; WO2025181336A1'),
 ('Sposób leczenia','Podanie preparatu lub komórek pacjentowi; istotny art. 53(c) EPC.','WO2025147212A1, zastrz. 27; prime editing, zastrz. 27')
],[126,268,105])
para('Sam fakt opublikowania zastrzeżenia nie świadczy o uzyskaniu prawa wyłącznego. W analizie należy rozdzielać wersję WO, zgłoszenie EP A1, dokumenty zmian zgłaszającego oraz ewentualny patent EP B1.')
hd('Sposób czytania zastrzeżenia niezależnego')
li('Wypisać wszystkie konieczne cechy: cel genomiczny, narzędzie edycji, RNA prowadzące, sekwencję, rodzaj komórek i wynik procesu.')
li('Dla nowości zestawiać ujawnienia element po elemencie i badać właściwą datę pierwszeństwa.')
li('Dla poziomu wynalazczego rozważyć najbliższy stan techniki, efekt techniczny i problem obiektywny.')

sec('8. BCL11A: Editas i Vertex','Dwa przykłady żądania ochrony dla regulatora ekspresji gamma-globiny')
para('<b>EP3981876A1 (Editas).</b> Pierwotne zastrzeżenie 1 dotyczyło gRNA kierującego cięcie związane z Cas9 do enhancera erytroidalnego BCL11A w intronie 2 lub do eksonu 2. W zestawie zmian z 18 stycznia 2023 r. usunięto alternatywę dotyczącą eksonu 2. Dokumenty badane dla tego przypadku obejmowały także opinię EPO z 14 marca 2022 r. i dokument D1 WO2015071474A2. [P1-P2]')
para('Opinia EPO z 2022 r. odnosiła się do wcześniejszego zestawu zastrzeżeń; nie można automatycznie przenosić jej ocen na zmiany z 2023 r. Porównanie wybranych sekwencji D1 i Editas wykazało podobieństwa, ale nie rozstrzygnęło lokalizacji genomowej, ujawnienia PAM ani nowości prawnej.')
para('<b>EP3749767A1 (Vertex).</b> Zastrzeżenie 1 opublikowanej wersji rodziny WO dotyczyło sposobu edycji BCL11A z użyciem endonukleazy DNA i sgRNA o sekwencji SEQ ID NO: 11 lub 12. Zastrzeżenie 2 wskazywało Cas9; dalsze określały m.in. formy dostarczania nukleazy i sygnały lokalizacji jądrowej. [P4]')
tab(['Przykład','Główna kategoria','Weryfikacja statusu EP'],[
 ('EP3981876A1','Produkt: gRNA w opublikowanej wersji; po zmianach zawężenie celu','Wniosek o badanie; brak potwierdzenia udzielenia'),
 ('EP3749767A1','Sposób edycji BCL11A; konkretne sgRNA','Wycofanie przez zgłaszającego 14.02.2025')
],[103,240,156])
para('Zbieżny cel biologiczny nie jest wystarczającym dowodem kolizji zastrzeżeń. Wymagana byłaby analiza całej treści i stanu prawnego odpowiednich spraw.')

sec('9. Promotory HBG: nikazy Cas9','Przegląd WO2025147212A1, opublikowanego zestawu 42 zastrzeżeń')
para('W WO2025147212A1 (Singapore Health Services) zaproponowano parę RNA prowadzących i nikazę Cas9 do modyfikowania miejsc wiązania represora LRF w promotorach HBG. W zastrzeżeniach zależnych pojawia się m.in. mutacja D10A oraz wskazane pary sekwencji gRNA. [P7]')
tab(['Zakres','Zastrzeżenia','Znaczenie'],[
 ('Zestaw z nikazą i parą gRNA','1-12','Produkt / zestaw narzędzi o określonym przeznaczeniu.'),
 ('Edycja komórek','13-26','Sposób modyfikowania locus HBG, także w HSPC.'),
 ('Terapia i profilaktyka','27-36','Etapy pobrania, edycji ex vivo, namnażania i podania komórek.'),
 ('Kompozycja i jej zastosowanie','37-42','Odrębne kategorie produktów i metod terapii.')
],[170,82,247])
para('Niezależne zastrzeżenie 1 nie jest ograniczone do konkretnej mutacji D10A ani wszystkich sekwencji zastrzeżeń zależnych. Rozróżnienie to jest niezbędne przy określaniu żądanego zakresu ochrony.')
hd('Uwagi prawne')
para('Zastrzeżenia obejmujące podawanie terapii pacjentowi wymagają oceny art. 53(c) EPC. Samodzielne zastrzeżenia produktowe oraz odrębne sposoby edycji ex vivo nie są z tego powodu automatycznie wyłączone. Brak zweryfikowanego statusu europejskiej fazy tego zgłoszenia uniemożliwia przypisywanie mu udzielonej ochrony EP.')

sec('10. Prime editing: porównanie regionów -115 i -200','Dwa odrębne zgłoszenia INSERM/AP-HP / Université Paris Cité / Fondation Imagine')
tab(['Cecha','Region -115','Region -200'],[
 ('Dokument WO','WO2025017033A1','WO2025017030A1'),
 ('Publikacja EP','EP4747377A1','EP4747376A1'),
 ('Cel represyjny','Miejsce wiązania BCL11A','Miejsce wiązania LRF'),
 ('Aktywatory','KLF1 i GATA1','KLF1 i TAL1'),
 ('Przykładowe zmiany','-124T&gt;C, -123T&gt;C, -113A&gt;G','-198T&gt;C, -175T&gt;C'),
 ('Narzędzie','PEmax, pegRNA; możliwe ngRNA/MLH1dn','PEmax, pegRNA; możliwe ngRNA/MLH1dn'),
 ('Zastrzeżenia WO','29','29')
],[125,186,188])
para('Oba rozwiązania zmieniają sekwencję promotorów HBG1/HBG2, lecz celują w inne regiony i inne miejsca regulatorowe. Numer pierwszeństwa dla -115 to EP23306230, a dla -200 EP23185855. Ustalono odrębne zgłoszenia PCT i europejskie. [P5-P6]')
hd('Uwaga dotycząca jasności')
para('W zastrzeżeniach 1 użyto sformułowania ograniczającego platformę do jednego edytora i jednego pegRNA, natomiast zastrzeżenia 20-25 dopuszczają drugi RNA prowadzący oraz czynniki związane z naprawą DNA. To punkt do oceny na gruncie art. 84 EPC, a nie potwierdzony zarzut egzaminatora.')

sec('11. Alternatywa: TALEN i korekcja HBB','Przypadek porównawczy, wyłączony ze statystyki technologii CRISPR')
para('WO2025181336A1 (Cellectis) obejmuje <b>73 zastrzeżenia</b> dotyczące korekcji wariantów genu HBB w hematopoetycznych komórkach macierzystych i progenitorowych. Technologia wykorzystuje nukleazy TALE oraz niewirusową matrycę naprawczą ssDNA, czyli nie jest CRISPR/Cas9. [P8]')
tab(['Zastrzeżenia','Główna kategoria'],[
 ('1-39','Sposób korekcji HBB ex vivo przez TALEN i HDR'),
 ('40-47','Zmodyfikowane komórki HSPC i ich populacje'),
 ('48-52','Kompozycje i produkty do zastosowania w terapii'),
 ('53-61','Nukleazy TALE oraz polinukleotydy i matryce DNA'),
 ('62-69','Zestawy do edycji i ich zastosowania ex vivo'),
 ('70-73','Sposoby leczenia, w tym podanie zmodyfikowanych komórek')
],[100,399])
para('Włączenie tej sprawy w charakterze porównawczym ułatwia pokazanie, że wspólny cel terapeutyczny nie oznacza wspólnej technologii edycji genomu.')
para('Zastrzeżenia 50-52 obejmują produkty do zastosowania terapeutycznego, podczas gdy 70 i 73 dotyczą sposobu leczenia pacjenta. W europejskim systemie patentowym wymagają odrębnej analizy odpowiednio art. 54(4)-(5) i art. 53(c) EPC.')

sec('12. Postępowania przed EPO','Statusy i zdarzenia potwierdzone w przekazanych wyciągach z rejestru')
tab(['Dokument EP','Status w dostarczonym rejestrze','Najważniejszy fakt'],[
 ('EP3981876A1','Wniosek o badanie','Zmiana zastrzeżeń 18.01.2023; brak potwierdzenia udzielenia.'),
 ('EP3887521A1','Wycofane','Wycofanie przez zgłaszającego 23.12.2024.'),
 ('EP3749767A1','Wycofane','Wycofanie przez zgłaszającego 14.02.2025.'),
 ('EP4747377A1','Wniosek o badanie','Zmiana zastrzeżeń lub opisu 15.01.2026.'),
 ('EP4747376A1','Wniosek o badanie','Zmiana zastrzeżeń lub opisu 15.01.2026.')
],[107,138,254])
para('Rejestry dwóch zgłoszeń prime editing miały datę aktualizacji bazy 13 listopada 2026 r. Odrębne wpisy dotyczące zmian państw rozszerzenia i walidacji nie stanowią decyzji o udzieleniu patentu.')
para('Nie ustalono przyczyn wycofania EP3887521 i EP3749767. Status wycofanego zgłoszenia EP nie rozstrzyga automatycznie losu jego zagranicznych odpowiedników.')
hd('Granice weryfikacji')
li('Dla EP4747376 i EP4747377 nie pozyskano pełnej wersji zastrzeżeń po zmianach 15.01.2026.')
li('Dla WO2025147212 i WO2025181336 nie potwierdzono aktualnego statusu regionalnej fazy EP.')
li('Do oceny skutecznego zakresu ochrony potrzebna jest analiza aktualnych zastrzeżeń i odpowiednich akt urzędowych.')

sec('13. Kwestie prawne w świetle EPC','Zagadnienia do dalszej oceny bez przypisywania EPO nieustalonych stanowisk')
tab(['Przepis','Zakres oceny','Zastosowanie w sprawach'],[
 ('Art. 53(c)','Wyłączenie sposobów terapii; odrębność produktów i produktów do zastosowania w terapii.','Sposoby podania zmodyfikowanych komórek.'),
 ('Art. 54(2)-(3)','Nowość i rozróżnienie wcześniejszego publicznego ujawnienia od wcześniejszego prawa EP.','D1 w analizie Editas; dokumenty cytowane dla HBG.'),
 ('Art. 56','Poziom wynalazczy, efekt techniczny i metoda problem-rozwiązanie.','Porównanie wariantów narzędzi i celów molekularnych.'),
 ('Art. 84','Jasność i poparcie zastrzeżeń opisem.','Zależności zastrzeżeń i wskazania SEQ ID NO.'),
 ('Art. 123(2)','Zakaz niedopuszczalnego rozszerzania przedmiotu po zmianach.','Zmiany Editas 2023 oraz zgłoszeń INSERM 2026.')
],[93,229,177])
para('Same oznaczenia cytowań X/Y w raporcie z poszukiwania nie przesądzają odmowy udzielenia patentu. Rozstrzygnięcie wymaga porównania cech odpowiedniego zastrzeżenia z ujawnionym stanem techniki oraz oceny dat i skuteczności pierwszeństwa.')
para('Oficjalne podstawy prawne: art. 53, 54, 56, 84 i 123 EPC oraz wytyczne EPO z 2026 r. [R2-R7]')

sec('14. Stan techniki i granice oceny','Dokumenty cytowane w poszukiwaniach nie są równoznaczne z rozstrzygnięciem EPO')
para('W aktach EP4747376 i EP4747377 przywołano m.in. <b>WO2022150790, WO2019173654, WO2021228944</b> oraz abstrakt Chalumeau i współautorów opublikowany w maju 2023 r. Niektóre pozycje zostały oznaczone kategoriami X/Y. Są to sygnały wskazujące dokumenty wymagające porównania z konkretnymi zastrzeżeniami, a nie ustalenie braku patentowalności. [P5-P6]')
para('W analizie EP3981876 porównano wybrane sekwencje zgłoszenia Editas z dokumentem D1 WO2015071474A2. Wykryta zbieżność fragmentów sekwencji jest ważnym punktem badawczym, ale bez potwierdzenia odpowiedniego kontekstu genomowego, PAM, rzeczywistego ujawnienia i dat pierwszeństwa nie pozwala stwierdzić braku nowości. [P1-P2]')
hd('Pytania pozostające otwarte')
li('Jaki jest aktualny zakres zmienionych zastrzeżeń EP4747376 i EP4747377 oraz czy odpowiada on opublikowanym zastrzeżeniom WO?')
li('Które spośród 25 publikacji tworzą odrębne proste rodziny DOCDB i jakie są ich faktyczne europejskie odpowiedniki?')
li('Jaką treść ujawniają wcześniejsze publikacje powołane przez urząd, w szczególności abstrakt Chalumeau z maja 2023 r.?')
para('Odpowiedzi wymagają pracy na pełnych aktach EPO i dokumentacji rodzin patentowych. Bez tych sprawdzeń nie należy formułować opinii o ważności patentów, naruszeniu praw ani swobodzie prowadzenia działalności (FTO).')

sec('15. Podsumowanie i wnioski końcowe','Najważniejsze odpowiedzi wynikające z porównania technologii i dokumentów')
para('<b>Wynik ogólny.</b> Badany obszar nie jest jednorodną kategorią patentową. Ten sam cel leczniczy, czyli poprawa funkcjonowania układu hemoglobinowego u pacjentów z beta-hemoglobinopatiami, można osiągać za pomocą różnych ingerencji genetycznych. Z tego powodu o możliwym zakresie ochrony decyduje nie tylko wskazana choroba, ale przede wszystkim <b>wybrany cel molekularny, sposób edycji, konkretne sekwencje i konstrukcja zastrzeżeń</b>.')
tab(['Ustalenie','Wynik w badanym materiale'],[
 ('Zakres zbioru','135 rekordów publikacji z jednego zapytania; nie 135 rodzin patentowych.'),
 ('Selekcja','25 publikacji wskazanych do pogłębionej oceny; ich rodziny wymagają końcowej weryfikacji.'),
 ('Studia przypadków','6 analiz technologii CRISPR i 1 analiza TALEN jako rozwiązania porównawczego.'),
 ('Postępowania EP','2 wycofane zgłoszenia i 3 zgłoszenia z odnotowanym wnioskiem o badanie; w żadnym z tych pięciu przypadków nie potwierdzono udzielenia na podstawie dostarczonego rejestru.')
],[113,386])
hd('Wniosek 1. Istnieją trzy odrębne drogi ingerencji w układ hemoglobinowy')
para('<b>BCL11A:</b> edycja regionu regulatorowego może osłabiać represję ekspresji gamma-globiny. <b>HBG1/HBG2:</b> zmiany bezpośrednio w promotorach mogą zaburzać wiązanie represorów BCL11A lub LRF albo tworzyć miejsca dla aktywatorów. <b>HBB:</b> alternatywnym celem jest korekcja chorobotwórczej sekwencji genu beta-globiny. Mechanizm regulacyjny i korekcja genu nie są rozwiązaniami tożsamymi; wymagają odrębnej analizy patentowej. [P1, P4-P8]')
hd('Wniosek 2. Podobny efekt biologiczny nie oznacza identycznego zakresu ochrony')
para('Editas żądał ochrony m.in. dla określonych gRNA, Vertex dla sposobu edycji BCL11A, natomiast inne zgłoszenia obejmują zestawy nikaza-gRNA, zmodyfikowane komórki, kompozycje i sposoby terapii. Podobieństwo celów leczniczych nie jest samo w sobie dowodem naruszenia, kolizji ani zależności między patentami. Decyduje brzmienie poszczególnych zastrzeżeń oraz ich status prawny. [P1, P4, P7]')
hd('Wniosek 3. W obrębie HBG można wyróżnić różne rozwiązania techniczne')
para('Zgłoszenie dotyczące par nikaz Cas9 koncentruje się na modyfikacji miejsc wiązania LRF. Dwa zgłoszenia prime editing przewidują natomiast precyzyjne zmiany nukleotydowe: wariant <b>-115</b> dotyczy m.in. miejsc BCL11A/KLF1/GATA1, zaś <b>-200</b> miejsc LRF/KLF1/TAL1. Są to odrębne zgłoszenia PCT i EP, pomimo wspólnej daty pierwszeństwa i tych samych zgłaszających. [P5-P7]')

sec('16. Znaczenie wyników i wnioski praktyczne','Co można stwierdzić, a czego nie potwierdzają dostępne materiały')
hd('Wniosek 4. Stan zgłoszenia europejskiego ma zasadnicze znaczenie')
para('EP3887521 i EP3749767 zostały wycofane przez zgłaszających. Dla EP3981876, EP4747376 i EP4747377 odnotowano wnioski o badanie, lecz w zbadanych wyciągach rejestrowych nie potwierdzono udzielenia patentu. <b>Wycofanie nie wyjaśnia przyczyny decyzji zgłaszającego</b> ani nie rozstrzyga sytuacji prawnej jego pozostałych zgłoszeń w innych państwach. Wniosek o badanie nie stanowi pozytywnej oceny patentowalności. [P1, P3-P6]')
hd('Wniosek 5. Nowość i poziom wynalazczy wymagają analizy poszczególnych cech')
para('Cytowania X/Y oraz podobieństwo wybranych fragmentów sekwencji w dokumentach Editas i wcześniejszego D1 wskazują obszary potencjalnie istotnego stanu techniki. Nie dowodzą jednak same przez się braku nowości ani poziomu wynalazczego. Konieczne jest zestawienie wszystkich cech konkretnego zastrzeżenia z treścią wcześniejszego dokumentu, weryfikacja dat oraz uwzględnienie zmian dokonanych w postępowaniu. [P1-P2, P5-P6]')
hd('Wniosek 6. Granica pomiędzy sposobem terapii a produktem jest istotna w EPO')
para('Zastrzeżenia obejmujące podanie zmodyfikowanych komórek pacjentowi mogą podlegać art. 53(c) EPC. Odmiennie należy oceniać samodzielne produkty, kompozycje, komórki przeznaczone do leczenia i sposoby modyfikacji komórek ex vivo. Dlatego sposób sformułowania zastrzeżenia może być równie ważny jak jego zawartość biologiczna. Jest to potencjalne zagadnienie prawne, a nie potwierdzone stanowisko EPO we wszystkich analizowanych sprawach. [R2-R3]')
hd('Co w praktyce wynika z tego badania?')
li('<b>Przy ocenie konkurencji</b> należy porównywać rodziny patentowe i rzeczywiste zastrzeżenia, a nie sumować liczbę publikacji lub opierać się wyłącznie na nazwie choroby.')
li('<b>Przy projektowaniu strategii zgłoszeniowej</b> warto osobno analizować ochronę narzędzi edycji, sekwencji prowadzących, procesu ex vivo oraz komórek lub kompozycji do terapii.')
li('<b>Przy analizie ryzyka</b> najpierw trzeba sprawdzić rejestr EPO, wersję zastrzeżeń po zmianach i odpowiednie wcześniejsze publikacje. Sam tekst WO A1 nie wystarcza do ustalenia aktualnej ochrony.')
hd('Ostateczna konkluzja')
para('<b>Najsilniejszym ustaleniem badania jest zróżnicowanie strategii ochrony patentowej dla terapii hemoglobinopatii.</b> Obserwowana różnorodność celów genomowych, metod edycji i kategorii zastrzeżeń uzasadnia wielowarstwową analizę prawną i techniczną. Zebrana dokumentacja pozwala porównać konkretne podejścia oraz wskazać obszary wymagające dalszych sprawdzeń, lecz nie uprawnia do wyznaczenia liczby niezależnych rodzin, oceny globalnej dominacji zgłaszających ani wydania opinii o swobodzie działania.')

sec('17. Źródła i zastrzeżenia metodyczne','Adresy urzędowych rejestrów i publikacji oraz granice zastosowania raportu')
for ident,desc,urlstr in [
 ('P1','Editas, EP3981876','https://register.epo.org/application?number=EP21170121&lng=en'),
 ('P2','Stan techniki D1, WO2015071474','https://patents.google.com/patent/WO2015071474A2/en'),
 ('P3','Editas, EP3887521','https://register.epo.org/application?number=EP19824433&lng=en'),
 ('P4','Vertex, EP3749767','https://register.epo.org/application?number=EP19713183&lng=en'),
 ('P5','Prime editing -115, EP4747377','https://register.epo.org/application?number=EP24745917&lng=en'),
 ('P6','Prime editing -200, EP4747376','https://register.epo.org/application?number=EP24740480&lng=en'),
 ('P7','Nikazy Cas9, WO2025147212','https://patents.google.com/patent/WO2025147212A1/en'),
 ('P8','TALEN, WO2025181336','https://patents.google.com/patent/WO2025181336A1/en'),
 ('R1','Rodziny patentowe DOCDB','https://www.epo.org/en/searching-for-patents/helpful-resources/first-time-here/patent-families/docdb'),
 ('R2','Art. 53 EPC','https://www.epo.org/en/legal/epc/2020/a53.html'),
 ('R3','Art. 54 EPC','https://www.epo.org/en/legal/epc/2020/a54.html'),
 ('R4','Art. 56 EPC','https://www.epo.org/en/legal/epc/2020/a56.html'),
 ('R5','Art. 84 EPC','https://www.epo.org/en/legal/epc/2020/a84.html'),
 ('R6','Art. 123 EPC','https://www.epo.org/en/legal/epc/2020/a123.html'),
 ('R7','Wytyczne EPO 2026','https://www.epo.org/en/legal/guidelines-epc/2026/index.html'),
]:
    para(f'[{ident}] {url(desc,urlstr)}','s')
para('<b>Ograniczenia.</b> Wyszukiwanie nie jest wyczerpującym badaniem wszystkich zgłoszeń z lat 2013-2026. Liczba publikacji nie stanowi liczby rodzin ani udzielonych patentów. Wybrane statusy zostały udokumentowane na podstawie wyciągów z rejestru przekazanych w listopadzie 2026 r. Wnioski prawne mają charakter wstępny i nie stanowią opinii o ważności, naruszeniu praw lub swobodzie działania.')


def cover(c,doc):
 c.saveState();c.setFillColor(N);c.rect(0,0,PW,PH,stroke=0,fill=1)
 c.setFillColor(T);c.rect(0,PH-27,PW,27,stroke=0,fill=1)
 c.setFillColor(colors.HexColor('#AADAD5'));c.setFont('DejaVu-Bold',10)
 c.drawString(48,PH-97,'ANALIZA PATENTOWA | PERSPEKTYWA EUROPEJSKA')
 ttl=ParagraphStyle('okladka',fontName='DejaVu-Bold',fontSize=25,leading=35,textColor=W)
 x=Paragraph('Edycja genomu CRISPR/Cas9<br/>w leczeniu hemoglobinopatii',ttl)
 x.wrapOn(c,PW-96,260);x.drawOn(c,48,PH-275)
 c.setFillColor(colors.HexColor('#BBE5DF'));c.setFont('DejaVu',13)
 c.drawString(48,PH-311,'Krajobraz patentowy | lata 2013-2026')
 c.setStrokeColor(colors.HexColor('#406377'));c.line(48,PH-371,PW-48,PH-371)
 c.setFillColor(colors.HexColor('#CCDCE7'));c.setFont('DejaVu',9.7)
 c.drawString(48,PH-352,'Analiza patentowa o charakterze badawczym')
 for i,(num,lab) in enumerate([('135','publikacji w zbiorze bibliograficznym'),('25','publikacji do dalszej oceny'),('6 + 1','analiz CRISPR i porównanie TALEN')]):
  yy=PH-440-i*45;c.setFillColor(W);c.setFont('DejaVu-Bold',18);c.drawString(48,yy,num)
  c.setFillColor(colors.HexColor('#C4D8E4'));c.setFont('DejaVu',9.3);c.drawString(130,yy+3,lab)
 c.setFont('DejaVu',8);c.setFillColor(colors.HexColor('#C4D8E4'))
 c.drawString(48,84,'Analiza zgłoszeń i publikacji, nie zestawienie potwierdzonych rodzin patentowych.')
 c.drawString(48,69,'Charakter badawczy. Dokument nie stanowi opinii prawnej ani oceny FTO.')
 c.restoreState()

def page(c,doc):
 c.saveState();c.setStrokeColor(colors.HexColor('#D6E4EB'));c.line(48,PH-37,PW-48,PH-37)
 c.setFont('DejaVu-Bold',7.3);c.setFillColor(B);c.drawString(48,PH-29,'KRAJOBRAZ PATENTOWY  |  CRISPR I HEMOGLOBINOPATIE')
 c.setFont('DejaVu',7);c.setFillColor(M);c.drawString(48,29,'ANALIZA PUBLIKACJI  |  PERSPEKTYWA EUROPEJSKA')
 c.drawRightString(PW-48,29,str(doc.page));c.restoreState()

pdf=SimpleDocTemplate(str(PDF),pagesize=A4,leftMargin=48,rightMargin=48,topMargin=51,bottomMargin=45,title='Edycja genomu CRISPR/Cas9 w leczeniu hemoglobinopatii. Krajobraz patentowy 2013-2026',author='Analiza patentowa',subject='Europejski krajobraz patentowy dla technologii edycji genomu')
pdf.build(flow,onFirstPage=cover,onLaterPages=page)
print('Raport:',PDF,'rozmiar:',PDF.stat().st_size)
