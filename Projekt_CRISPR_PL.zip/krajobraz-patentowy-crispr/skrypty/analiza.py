#!/usr/bin/env python3
"""Odtwarza wykresy dotyczące publikacji patentowych z eksportu Espacenet."""
from pathlib import Path
from collections import Counter
import csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'wykresy'
OUT.mkdir(exist_ok=True)
with (ROOT/'dane'/'publikacje_135.csv').open(encoding='utf-8-sig',newline='') as f:
    dane=list(csv.DictReader(f))
assert len(dane)==135
assert len({r['Publikacja'] for r in dane})==135
lata=Counter(int(r['Rok pierwszeństwa']) for r in dane)
urzed=Counter(r['Urząd'] for r in dane)
zg=Counter(r['Pierwszy zgłaszający'] for r in dane)
kategorie=Counter(r['Klasa selekcji'][0] for r in dane)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.5,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':190})

def zapisz(nazwa):
    plt.tight_layout(pad=1.6)
    plt.savefig(OUT/nazwa,bbox_inches='tight')
    plt.close()

fig,ax=plt.subplots(figsize=(9.5,4.1));xs=sorted(lata)
ax.bar([str(n) for n in xs],[lata[n] for n in xs],color='#29877B')
ax.set_title('Publikacje według najwcześniejszego roku pierwszeństwa (n = 135)',loc='left',pad=13,fontweight='bold')
ax.set_ylabel('Liczba publikacji');ax.set_xlabel('Rok pierwszeństwa w danych Espacenet')
ax.tick_params(axis='x',rotation=40)
ax.set_ylim(0,max(lata.values())+6)
for i,rok in enumerate(xs): ax.text(i,lata[rok]+.5,str(lata[rok]),ha='center',fontsize=8)
zapisz('lata_pierwszenstwa.png')

fig,ax=plt.subplots(figsize=(9.5,3.6));kolejnosc=['US','WO','CN','EP','JP','CA']
vals=[urzed.get(k,0) for k in kolejnosc]
ax.bar(kolejnosc,vals,color='#32738A');ax.set_title('Urząd lub droga publikacji',loc='left',pad=12,fontweight='bold')
ax.set_ylabel('Liczba publikacji');ax.set_xlabel('WO oznacza publikację międzynarodową, nie udzielony patent')
ax.set_ylim(0,90)
for i,v in enumerate(vals):ax.text(i,v+1,str(v),ha='center')
zapisz('urzedy_publikacji.png')

fig,ax=plt.subplots(figsize=(9.5,3.8));cats=['A','B','C','D']; labs=['A: kandydat bezpośredni','B: wymaga weryfikacji','C: technologia pokrewna','D: poza zakresem']
vals=[kategorie.get(k,0) for k in cats]
ax.barh(labs[::-1],vals[::-1],color='#32738A');ax.set_xlim(0,45)
ax.set_title('Wstępna selekcja według danych bibliograficznych',loc='left',pad=12,fontweight='bold')
ax.set_xlabel('Liczba publikacji (kwalifikacja wstępna)')
for i,v in enumerate(vals[::-1]):ax.text(v+.4,i,str(v),va='center')
zapisz('selekcja_wstepna.png')

fig,ax=plt.subplots(figsize=(9.5,4.3));top=zg.most_common(8)
names=[a for a,_ in top][::-1]; vals=[v for _,v in top][::-1]
ax.barh(names,vals,color='#29877B');ax.set_xlim(0,max(vals)+3)
ax.set_title('Najczęstsi pierwsi zgłaszający w wynikach wyszukiwania',loc='left',pad=12,fontweight='bold')
ax.set_xlabel('Liczba publikacji, nie liczba rodzin patentowych')
for i,v in enumerate(vals):ax.text(v+.18,i,str(v),va='center')
zapisz('zglaszajacy.png')
print('Utworzono 4 wykresy w języku polskim, rekordów:',len(dane))
